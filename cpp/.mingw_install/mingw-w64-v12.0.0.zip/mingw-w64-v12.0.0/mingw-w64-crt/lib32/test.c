/* Perform simple test of headers to avoid typos and such */
#include <windows.h>
#include <d3d9.h>
#include <d3d9caps.h>
#include <d3d9types.h>
#include <dxerr8.h>
#include <dxerr9.h>

int main()
{
  return 0;
}
