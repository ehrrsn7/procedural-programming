
#include <oaidl.h>
#include <ocidl.h>

#include <initguid.h>
#include <dxgi.h>
#include <wincodec.h>
