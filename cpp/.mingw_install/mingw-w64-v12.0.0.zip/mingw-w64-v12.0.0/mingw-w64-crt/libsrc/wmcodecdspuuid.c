
#include <windows.h>
#include <propsys.h>
#include <mediaobj.h>
#include <strmif.h>

#include <initguid.h>
#include <wmcodecdsp.h>
